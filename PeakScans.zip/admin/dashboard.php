<?php
session_start();
require_once '../Components/db.php';
require_once '../Components/auth.php';


if (!isset($_SESSION['uid'])) {
    header("Location: ../Components/login.php");
    exit();
}


checkRole('admin');


if (isset($_POST['update_role']) && isset($_POST['user_id']) && isset($_POST['role'])) {
    $update_id = $_POST['user_id'];
    $new_role = $_POST['role'];
    
    
    if ($update_id != $_SESSION['uid']) {
        $update_role = $conn->prepare("UPDATE User SET role = ? WHERE uid = ?");
        $update_role->bind_param("si", $new_role, $update_id);
        $update_role->execute();
        
        
        $conn->query("CALL AssignPermissions()");
        
       
        if (isset($_SESSION['permissions'])) {
           
            $perm_query = $conn->prepare("SELECT * FROM UserPermissions WHERE user_id = ?");
            $perm_query->bind_param("i", $_SESSION['uid']);
            $perm_query->execute();
            $permissions = $perm_query->get_result()->fetch_assoc();
            
            if ($permissions) {
                $_SESSION['permissions'] = [
                    'upload' => $permissions['can_upload'],
                    'edit' => $permissions['can_edit'],
                    'delete' => $permissions['can_delete'],
                    'manage_users' => $permissions['can_manage_users']
                ];
            }
        }
        
        
        header('Location: dashboard.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PeakScans Admin Dashboard</title>
    <link rel="stylesheet" href="../Resources/dashboard.css">

</head>
<body>
    <div class="navbar">
        <a href="../index.php">Back to Site</a>
        <a href="../Components/logout.php">Logout</a>
    </div>

    <h1>PeakScans Admin Dashboard</h1>
    
    <section>
        <h2>User Management</h2>
        <?php
        
        $users = $conn->query("SELECT u.uid, u.username, u.email, u.role, u.registration_date, 
                               p.can_upload, p.can_edit, p.can_delete, p.can_manage_users 
                               FROM User u 
                               LEFT JOIN UserPermissions p ON u.uid = p.user_id
                               ORDER BY u.uid");
        
        if ($users->num_rows > 0):
        ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Registration Date</th>
                <th>Permissions</th>
                <th>Actions</th>
            </tr>
            <?php while($user = $users->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($user['uid']) ?></td>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td>
                    <form action="dashboard.php" method="POST">
                        <input type="hidden" name="user_id" value="<?= $user['uid'] ?>">
                        <select name="role" <?= $user['uid'] == $_SESSION['uid'] ? 'disabled' : '' ?>>
                            <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>User</option>
                            <option value="editor" <?= $user['role'] === 'editor' ? 'selected' : '' ?>>Editor</option>
                            <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                        </select>
                        <?php if ($user['uid'] != $_SESSION['uid']): ?>
                            <button type="submit" name="update_role">Update</button>
                        <?php else: ?>
                            (Current user)
                        <?php endif; ?>
                    </form>
                </td>
                <td><?= htmlspecialchars($user['registration_date']) ?></td>
                <td>
                    Upload: <?= $user['can_upload'] ? '✓' : '✗' ?><br>
                    Edit: <?= $user['can_edit'] ? '✓' : '✗' ?><br>
                    Delete: <?= $user['can_delete'] ? '✓' : '✗' ?><br>
                    Manage Users: <?= $user['can_manage_users'] ? '✓' : '✗' ?>
                </td>
                <td class="actions">
                    <?php if ($user['uid'] != $_SESSION['uid']): ?>
                        <a href="./Components/view_user.php?id=<?= $user['uid'] ?>">View</a>
                        <a class="delete" href="../Components/delete_user.php?id=<?= $user['uid'] ?>" 
                           onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                    <?php else: ?>
                        (Current user)
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        <?php else: ?>
            <p>No users found in the database.</p>
        <?php endif; ?>
    </section>

    <section>
        <h2>System Info</h2>
        <p>Database: PeakScans</p>
        <p>Total Users: <?= $users->num_rows ?></p>
        <button onclick="location.href='../Components/update_permissions.php'">Refresh User Permissions</button>
    </section>
</body>
</html>