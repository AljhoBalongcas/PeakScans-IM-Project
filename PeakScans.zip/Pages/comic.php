<?php
require '../Components/db.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Comics - PeakScans</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../Resources/comic.css">
</head>
<body>
    <?php include '../Components/comicbar.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">Browse Comics</h1>
            <div>
                <?php if(isset($_SESSION['uid']) && $_SESSION['permissions']['upload']): ?>
                    <a href="upload.php" class="filter-button">
                        <i class="bi bi-plus-lg"></i> Upload
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="filter-bar">
            <input type="text" class="search-input" placeholder="Search comics..." id="search-input">
            <button class="filter-button">
                <i class="bi bi-funnel"></i> Filters
            </button>
            <button class="filter-button">
                <i class="bi bi-sort-down"></i> Sort
            </button>
        </div>
        
        <div class="comics-grid">
            <?php
            $query = "SELECT c.comic_id, c.title, c.author, c.status, 
                     (SELECT language FROM translation WHERE comic_id = c.comic_id LIMIT 1) as language,
                     (SELECT COUNT(*) FROM chapter WHERE comic_id = c.comic_id) as chapter_count
                     FROM comic c
                     ORDER BY c.date_added DESC
                     LIMIT 20";
            
            $result = $conn->query($query);
            
            if ($result->num_rows > 0):
                while($comic = $result->fetch_assoc()):
                    $cover_path = "../Resources/covers/" . $comic['comic_id'] . ".jpg";
                    if (!file_exists($cover_path)) {
                        $cover_path = "../Resources/default-cover.jpg";
                    }
            ?>
            <a href="comic-detail.php?id=<?= $comic['comic_id'] ?>" class="comic-card">
                <img src="<?= $cover_path ?>" alt="<?= htmlspecialchars($comic['title']) ?>" class="comic-cover">
                <span class="comic-badge status-<?= strtolower($comic['status']) ?>">
                    <?= ucfirst($comic['status']) ?>
                </span>
                <div class="comic-overlay">
                    <h3 class="comic-title"><?= htmlspecialchars($comic['title']) ?></h3>
                    <div class="comic-meta">
                        <span><?= $comic['chapter_count'] ?> chs</span>
                        <span><?= $comic['language'] ?? 'EN' ?></span>
                    </div>
                </div>
            </a>
            <?php
                endwhile;
            else:
            ?>
            <div class="empty-state">
                <div class="empty-icon">
                    <i class="bi bi-book"></i>
                </div>
                <h2 class="empty-title">No Comics Found</h2>
                <p class="empty-description">
                    We couldn't find any comics in our database. Check back later or upload your own.
                </p>
                <?php if(isset($_SESSION['uid']) && $_SESSION['permissions']['upload']): ?>
                    <a href="upload.php" class="empty-action">Upload Your First Comic</a>
                <?php else: ?>
                    <a href="../Components/login.php" class="empty-action">Login to Upload</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.getElementById('search-input').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            document.querySelectorAll('.comic-card').forEach(card => {
                const title = card.querySelector('.comic-title').textContent.toLowerCase();
                card.style.display = title.includes(searchTerm) ? 'block' : 'none';
            });
        });
    </script>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</body>
</html>