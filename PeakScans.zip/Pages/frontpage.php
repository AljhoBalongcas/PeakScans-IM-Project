<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PeakScans - Manga Database</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="./resources/style.css">
</head>
<body>

<div class="front">
    <div class="front-content">
        <h1>Join PeakScans</h1>
            <p class="subtitle">A manga database and community</p>
             <p class="description">to discover and discuss your favorite manga series with fellow fans.</p>
                <a href="./Pages/comic.php" class="get-started-button">Get started</a>
</div>
</div>

<div class="stats-wrapper">
    <h2>This Week, We Have</h2>
    <div class="stats-cards">
        <div class="stat-card">
            <div class="stat-number" id="comics-count"></div>
            <div class="stat-label">New comics</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" id="chapters-count"></div>
            <div class="stat-label">New chapters</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" id="users-count"></div>
            <div class="stat-label">New users</div>
        </div>
    </div>
</div>

<script>
// ANIMATIONS
async function fetchStats() {
    try {
        const response = await fetch('get_stats.php');
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        
        if (data.status === 'error') {
            console.error('Backend error:', data.message);
            // Set some default values if there's an error
            document.getElementById("comics-count").textContent = '0';
            document.getElementById("chapters-count").textContent = '0';
            document.getElementById("users-count").textContent = '0';
            return;
        }
        
        animateValue("comics-count", 0, data.new_comics, 1500);
        animateValue("chapters-count", 0, data.new_chapters, 1500);
        animateValue("users-count", 0, data.new_users, 1800);
        
    } catch (error) {
        console.error('Error fetching stats:', error);
        document.getElementById("comics-count").textContent = '0';
        document.getElementById("chapters-count").textContent = '0';
        document.getElementById("users-count").textContent = '0';
    }
}

function animateValue(id, start, end, duration) {
    const obj = document.getElementById(id);
    if (!obj) return;
    
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        obj.textContent = Math.floor(progress * (end - start) + start).toLocaleString();
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// Run on load and refresh every 5 minutes
window.addEventListener('DOMContentLoaded', () => {
    fetchStats();
    setInterval(fetchStats, 300000); // 300000ms = 5 minutes
});
</script>
</div>
</body>
</html>