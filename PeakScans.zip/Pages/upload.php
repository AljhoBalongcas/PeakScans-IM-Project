<?php
require '../Components/db.php';
require '../Components/auth.php';
session_start();


if (!isset($_SESSION['uid']) || !hasPermission('upload')) {
    header("Location: /login.php?redirect=upload");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $description = trim($_POST['description']);
    $status = $_POST['status'];
    $genres = $_POST['genres'] ?? [];
    
    try {
        
        if (empty($title)) {
            throw new Exception("Title is required");
        }
        
        
        $conn->begin_transaction();
        
       
        $stmt = $conn->prepare("INSERT INTO comic (title, author, description, status, date_added) 
                              VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssss", $title, $author, $description, $status);
        $stmt->execute();
        $comic_id = $conn->insert_id;
        
        
        $genre_stmt = $conn->prepare("INSERT INTO comicgenre (comic_id, genre_id) VALUES (?, ?)");
        foreach ($genres as $genre_id) {
            $genre_id = (int)$genre_id;
            $genre_stmt->bind_param("ii", $comic_id, $genre_id);
            $genre_stmt->execute();
        }
        
       
        if (isset($_FILES['cover']) && $_FILES['cover']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $filename = $_FILES['cover']['name'];
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            
            if (in_array(strtolower($ext), $allowed)) {
               
                $upload_dir = "../Resources/covers/";
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
               
                $target_path = $upload_dir . $comic_id . ".jpg";
                
                if (move_uploaded_file($_FILES['cover']['tmp_name'], $target_path)) {
                   
                    if ($ext != 'jpg' && $ext != 'jpeg') {
                        $source = imagecreatefromstring(file_get_contents($target_path));
                        imagejpeg($source, $target_path, 90);
                        imagedestroy($source);
                    }
                } else {
                    throw new Exception("Failed to upload cover image");
                }
            } else {
                throw new Exception("Invalid image format. Allowed formats: JPG, PNG, GIF");
            }
        }
        
        
        $conn->commit();
        
        $success = "Comic uploaded successfully!";
        $_POST = []; 
        
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error: " . $e->getMessage();
    }
}


$genres = $conn->query("SELECT * FROM genre ORDER BY genre_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Comic - PeakScans</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../Resources/upload.css">
</head>
<body>
    <?php include '../Components/comicbar.php'; ?>
    
    <div class="upload-container">
        <h1>Upload New Comic</h1>
        
        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Title*</label>
                <input type="text" id="title" name="title" required 
                       value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="author">Author</label>
                <input type="text" id="author" name="author" 
                       value="<?php echo htmlspecialchars($_POST['author'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description"><?php 
                    echo htmlspecialchars($_POST['description'] ?? ''); 
                ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="ongoing" <?php echo ($_POST['status'] ?? '') === 'ongoing' ? 'selected' : ''; ?>>Ongoing</option>
                    <option value="completed" <?php echo ($_POST['status'] ?? '') === 'completed' ? 'selected' : ''; ?>>Completed</option>
                    <option value="hiatus" <?php echo ($_POST['status'] ?? '') === 'hiatus' ? 'selected' : ''; ?>>Hiatus</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Genres</label>
                <div class="checkbox-group">
                    <?php while ($genre = $genres->fetch_assoc()): ?>
                        <label class="checkbox-label">
                            <input type="checkbox" name="genres[]" value="<?php echo $genre['genre_id']; ?>"
                                <?php echo in_array($genre['genre_id'], $_POST['genres'] ?? []) ? 'checked' : ''; ?>>
                            <?php echo htmlspecialchars($genre['genre_name']); ?>
                        </label>
                    <?php endwhile; ?>
                </div>
            </div>
            
            <div class="form-group">
                <label for="cover">Cover Image</label>
                <input type="file" id="cover" name="cover" accept="image/*">
                <p class="form-help">Recommended size: 600x800 pixels. Will be displayed as a thumbnail.</p>
            </div>
            
            <button type="submit" class="submit-btn">Upload Comic</button>
        </form>
    </div>
    
    <script>
       
        document.getElementById('cover').addEventListener('change', function(e) {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    
                    let preview = document.getElementById('cover-preview');
                    if (!preview) {
                        preview = document.createElement('div');
                        preview.id = 'cover-preview';
                        preview.classList.add('cover-preview');
                        document.querySelector('.form-group label[for="cover"]').after(preview);
                    }
                    preview.innerHTML = `<img src="${e.target.result}" alt="Cover Preview">`;
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>