<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get Started - PeakScans</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./Resources/frontpage2.css">
</head>
<body>
    <div class="get-started-container">
        <div class="header">
            <h1>Start Your Manga Journey</h1>
            <p class="subtitle">Join thousands of manga fans discovering, reading, and discussing their favorite series on PeakScans</p>
        </div>
        
        <div class="steps-container">
            <div class="step-card">
                <div class="step-number">1</div>
                <h3 class="step-title">Create Your Account</h3>
                <p class="step-description">Sign up in seconds to unlock personalized recommendations and track your reading progress.</p>
            </div>
            
            <div class="step-card">
                <div class="step-number">2</div>
                <h3 class="step-title">Explore Our Library</h3>
                <p class="step-description">Discover thousands of manga series across all genres, from action to romance.</p>
            </div>
            
            <div class="step-card">
                <div class="step-number">3</div>
                <h3 class="step-title">Join the Community</h3>
                <p class="step-description">Discuss chapters, rate series, and connect with fellow manga enthusiasts.</p>
            </div>
        </div>
        
        <div class="action-buttons">
            <a href="./Components/register.php" class="btn btn-primary">Sign Up Now</a>
            <a href="./Pages/comic.php" class="btn btn-outline">Browse as Guest</a>
        </div>
        
        <div class="popular-genres">
            <h2>Popular Genres</h2>
            <div class="genres-grid">
                <?php
                require_once './Components/db.php';
                
              
                $genres = $conn->query("
                    SELECT g.genre_name, COUNT(cg.comic_id) as comic_count 
                    FROM genre g
                    LEFT JOIN comicgenre cg ON g.genre_id = cg.genre_id
                    GROUP BY g.genre_name
                    ORDER BY comic_count DESC
                    LIMIT 12
                ");
                
                while($genre = $genres->fetch_assoc()) {
                    echo '<div class="genre-card">' . htmlspecialchars($genre['genre_name']) . '</div>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>