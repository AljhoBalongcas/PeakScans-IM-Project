<?php
require_once '../Components/auth.php';
checkRole('editor');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Editor Dashboard</title>
</head>
<body>
    <h1>Editor Dashboard</h1>
    
    <section>
        <h2>Pending Translations</h2>
        <?php
        require '../Components/db.php';
        $translations = $conn->query("
            SELECT t.translation_id, c.title, t.language, t.status 
            FROM translation t
            JOIN comic c ON t.comic_id = c.comic_id
            WHERE t.status = 'pending'
        ");
        ?>
        <ul>
            <?php while($trans = $translations->fetch_assoc()): ?>
            <li>
                <?= htmlspecialchars($trans['title']) ?> - 
                <?= htmlspecialchars($trans['language']) ?>
                <a href="edit_translation.php?id=<?= $trans['translation_id'] ?>">Review</a>
            </li>
            <?php endwhile; ?>
        </ul>
    </section>
</body>
</html>