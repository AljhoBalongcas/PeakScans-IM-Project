<?php
session_start();
session_destroy();
header("Location: /PEAKSCANS/index.php");
exit();
