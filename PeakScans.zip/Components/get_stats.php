<?php
require_once 'db.php';

header('Content-Type: application/json');

try {
    // Get new comics count (last 7 days)
    $new_comics = $conn->query("
        SELECT COUNT(*) as count FROM comic 
        WHERE date_added >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ")->fetch_assoc()['count'] ?? 0;

    // Get new chapters count (last 7 days)
    $new_chapters = $conn->query("
        SELECT COUNT(DISTINCT t.comic_id) as count 
        FROM translation t
        INNER JOIN comic c ON t.comic_id = c.comic_id
        WHERE t.status = 'completed'
        AND t.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ")->fetch_assoc()['count'] ?? 0;

    // Get new users count (last 7 days)
    $new_users = $conn->query("
        SELECT COUNT(DISTINCT uid) as count 
        FROM user 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ")->fetch_assoc()['count'] ?? 0;

    echo json_encode([
        'new_comics' => (int)$new_comics,
        'new_chapters' => (int)$new_chapters,
        'new_users' => (int)$new_users,
        'status' => 'success'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'new_comics' => 0,
        'new_chapters' => 0,
        'new_users' => 0,
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>