<?php
require_once 'db.php';

$comic_id = $_GET['id'];

$comic = $conn->query("SELECT * FROM Comic WHERE comic_id = $comic_id")->fetch_assoc();
$comic['translations'] = $conn->query("SELECT language, translation_text FROM Translation WHERE comic_id = $comic_id")->fetch_all(MYSQLI_ASSOC);
$comic['genres'] = $conn->query("
  SELECT g.genre_name FROM Genre g
  JOIN ComicGenre cg ON g.genre_id = cg.genre_id
  WHERE cg.comic_id = $comic_id
")->fetch_all(MYSQLI_ASSOC);
$comic['comments'] = $conn->query("
  SELECT u.username, c.comment FROM Comment c
  JOIN User u ON c.uid = u.uid
  WHERE c.comic_id = $comic_id
")->fetch_all(MYSQLI_ASSOC);

header('Content-Type: application/json');
echo json_encode($comic);
