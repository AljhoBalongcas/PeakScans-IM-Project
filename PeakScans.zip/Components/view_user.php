<?php
session_start();
require_once '../Components/db.php';


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}


$user_id = $_SESSION['user_id'];
$check_admin = $conn->prepare("SELECT role FROM User WHERE uid = ?");
$check_admin->bind_param("i", $user_id);
$check_admin->execute();
$result = $check_admin->get_result();

if ($result->num_rows === 0 || $result->fetch_assoc()['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}


if (!isset($_GET['id'])) {
    header('Location: ../admin/dashboard.php');
    exit;
}

$view_id = $_GET['id'];
$user_query = $conn->prepare("SELECT u.*, p.* FROM User u 
                           LEFT JOIN UserPermissions p ON u.uid = p.user_id
                           WHERE u.uid = ?");
$user_query->bind_param("i", $view_id);
$user_query->execute();
$user = $user_query->get_result()->fetch_assoc();

if (!$user) {
    header('Location: ../admin/dashboard.php?error=user_not_found');
    exit;
}


$comments_query = $conn->prepare("SELECT c.*, cm.title 
                               FROM Comment c 
                               JOIN Comic cm ON c.comic_id = cm.comic_id
                               WHERE c.uid = ?
                               ORDER BY c.comment_id DESC");
$comments_query->bind_param("i", $view_id);
$comments_query->execute();
$comments = $comments_query->get_result();


$ratings_query = $conn->prepare("SELECT r.*, c.title 
                              FROM Rating r 
                              JOIN Comic c ON r.comic_id = c.comic_id 
                              WHERE r.uid = ?");
$ratings_query->bind_param("i", $view_id);
$ratings_query->execute();
$ratings = $ratings_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Details - PeakScans Admin</title>
    <link rel="stylesheet" href="../Resources/dashboard.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .user-info {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .back-button {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background-color: #f0f0f0;
            text-decoration: none;
            color: #333;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <a href="../admin/dashboard.php" class="back-button">← Back to Dashboard</a>
    
    <h1>User Details</h1>
    
    <div class="user-info">
        <h2><?= htmlspecialchars($user['username']) ?></h2>
        <p><strong>ID:</strong> <?= htmlspecialchars($user['uid']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
        <p><strong>Role:</strong> <?= htmlspecialchars($user['role']) ?></p>
        <p><strong>Registration Date:</strong> <?= htmlspecialchars($user['registration_date']) ?></p>
        
        <h3>Permissions</h3>
        <p>Upload: <?= $user['can_upload'] ? '✓' : '✗' ?></p>
        <p>Edit: <?= $user['can_edit'] ? '✓' : '✗' ?></p>
        <p>Delete: <?= $user['can_delete'] ? '✓' : '✗' ?></p>
        <p>Manage Users: <?= $user['can_manage_users'] ? '✓' : '✗' ?></p>
    </div>
    
    <h2>User Comments</h2>
    <?php if ($comments->num_rows > 0): ?>
    <table>
        <tr>
            <th>Comic</th>
            <th>Comment</th>
        </tr>
        <?php while($comment = $comments->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($comment['title']) ?></td>
            <td><?= htmlspecialchars($comment['comment']) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <?php else: ?>
    <p>This user hasn't made any comments yet.</p>
    <?php endif; ?>
    
    <h2>User Ratings</h2>
    <?php if ($ratings->num_rows > 0): ?>
    <table>
        <tr>
            <th>Comic</th>
            <th>Rating</th>
        </tr>
        <?php while($rating = $ratings->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($rating['title']) ?></td>
            <td><?= htmlspecialchars($rating['rating']) ?> / 5</td>
        </tr>
        <?php endwhile; ?>
    </table>
    <?php else: ?>
    <p>This user hasn't rated any comics yet.</p>
    <?php endif; ?>
</body>
</html>