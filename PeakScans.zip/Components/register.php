<?php
require 'db.php';
session_start();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $invite_code = trim($_POST['invite_code'] ?? '');
    
    
    $role = 'user';
    
 
    if ($invite_code === 'EDITOR123') {
        $role = 'editor';
    } elseif ($invite_code === 'ADMIN456') {
       
        $role = 'admin';
    }

  
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO User (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $email, $hashed_password, $role);
    
    if ($stmt->execute()) {
        $user_id = $stmt->insert_id;
        
      
        $default_upload = ($role === 'editor' || $role === 'admin') ? 1 : 0;
        $default_edit = ($role === 'editor' || $role === 'admin') ? 1 : 0;
        
        $perm_stmt = $conn->prepare("INSERT INTO UserPermissions 
                                   (user_id, can_upload, can_edit, can_delete, can_manage_users) 
                                   VALUES (?, ?, ?, ?, ?)");
        $can_delete = ($role === 'admin') ? 1 : 0;
        $can_manage = ($role === 'admin') ? 1 : 0;
        $perm_stmt->bind_param("iiiii", $user_id, $default_upload, $default_edit, $can_delete, $can_manage);
        $perm_stmt->execute();
        
        $_SESSION['registration_success'] = true;
        header("Location: login.php");
        exit();
    } else {
        $error = "Registration failed. Please try again later.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - PeakScans</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../Resources/register.css">
</head>
<body>
    <div class="register-container">
        <div class="logo">
            <img src="../Resources/PeakScansLogo1.jpg" alt="PeakScans Logo">
            <h1>Create Your Account</h1>
            <p>Join our manga community today</p>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['registration_success'])): ?>
            <?php unset($_SESSION['registration_success']); ?>
            <div class="success-message">
                Registration successful! Please login.
            </div>
        <?php endif; ?>
        
        <form method="POST" id="registerForm">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" required 
                       value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" class="form-control" required 
                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-container">
                    <input type="password" id="password" name="password" class="form-control" required>
                    <span class="toggle-password" onclick="togglePasswordVisibility('password')">
                        <i class="bi bi-eye"></i>
                    </span>
                </div>
                <div class="password-strength">
                    <div class="strength-meter" id="strengthMeter"></div>
                </div>
                <div class="requirements">
                    <div class="requirement" id="lengthReq">
                        <i class="bi" id="lengthIcon"></i>
                        <span>At least 8 characters</span>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <div class="password-container">
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                    <span class="toggle-password" onclick="togglePasswordVisibility('confirm_password')">
                        <i class="bi bi-eye"></i>
                    </span>
                </div>
                <div id="passwordMatch" class="requirements"></div>
            </div>
            
            <button type="submit" class="btn btn-primary">Create Account</button>
            
            <div class="divider">or</div>
            
            <div class="alternative-actions">
                Already have an account? <a href="login.php">Login</a>
            </div>
        </form>
    </div>

    <script>
        function togglePasswordVisibility(fieldId) {
            const passwordInput = document.getElementById(fieldId);
            const toggleIcon = document.querySelector(`#${fieldId} + .toggle-password i`);
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            }
        }

        // Password strength checker
        const passwordInput = document.getElementById('password');
        const strengthMeter = document.getElementById('strengthMeter');
        const lengthReq = document.getElementById('lengthReq');
        const lengthIcon = document.getElementById('lengthIcon');
        
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            const length = password.length;
            
            // Update strength meter
            if (length === 0) {
                strengthMeter.style.width = '0%';
                strengthMeter.style.backgroundColor = 'var(--error)';
            } else if (length < 4) {
                strengthMeter.style.width = '25%';
                strengthMeter.style.backgroundColor = 'var(--error)';
            } else if (length < 8) {
                strengthMeter.style.width = '50%';
                strengthMeter.style.backgroundColor = '#F59E0B';
            } else {
                strengthMeter.style.width = '100%';
                strengthMeter.style.backgroundColor = 'var(--success)';
            }
            
            // Update requirements
            if (length >= 8) {
                lengthIcon.className = 'bi bi-check-circle-fill valid';
                lengthReq.style.color = 'var(--success)';
            } else {
                lengthIcon.className = 'bi bi-x-circle-fill invalid';
                lengthReq.style.color = 'var(--error)';
            }
        });

        // Password match checker
        const confirmPassword = document.getElementById('confirm_password');
        const passwordMatch = document.getElementById('passwordMatch');
        
        confirmPassword.addEventListener('input', function() {
            if (this.value !== passwordInput.value) {
                passwordMatch.innerHTML = '<i class="bi bi-x-circle-fill invalid"></i> Passwords do not match';
                passwordMatch.style.color = 'var(--error)';
            } else {
                passwordMatch.innerHTML = '<i class="bi bi-check-circle-fill valid"></i> Passwords match';
                passwordMatch.style.color = 'var(--success)';
            }
        });
    </script>
    
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</body>
</html>