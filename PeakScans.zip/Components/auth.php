<?php
function checkRole($required_role) {
    if (!isset($_SESSION['role'])) {
        header("Location: /Components/login.php");
        exit();
    }
    
    $hierarchy = ['user' => 1, 'editor' => 2, 'admin' => 3];
    
    if ($hierarchy[$_SESSION['role']] < $hierarchy[$required_role]) {
        header("Location: /unauthorized.php");
        exit();
    }
}

function hasPermission($permission) {
    return isset($_SESSION['permissions'][$permission]) && $_SESSION['permissions'][$permission] === 1;
}
?>