<?php
session_start();
require_once '../Components/db.php';
require_once '../Components/auth.php';


if (!isset($_SESSION['uid'])) {
    header("Location: ../Components/login.php");
    exit();
}


checkRole('admin');


if (isset($_GET['id'])) {
    $delete_id = $_GET['id'];
    

    if ($delete_id == $_SESSION['uid']) {
        header('Location: admin_dashboard.php?error=cannot_delete_self');
        exit;
    }
    

    $conn->begin_transaction();
    
    try {
        
        $delete_permissions = $conn->prepare("DELETE FROM UserPermissions WHERE user_id = ?");
        $delete_permissions->bind_param("i", $delete_id);
        $delete_permissions->execute();
        
      
        $delete_ratings = $conn->prepare("DELETE FROM Rating WHERE uid = ?");
        $delete_ratings->bind_param("i", $delete_id);
        $delete_ratings->execute();
        
        
        $delete_comments = $conn->prepare("DELETE FROM Comment WHERE uid = ?");
        $delete_comments->bind_param("i", $delete_id);
        $delete_comments->execute();
        
       
        $delete_user = $conn->prepare("DELETE FROM User WHERE uid = ?");
        $delete_user->bind_param("i", $delete_id);
        $delete_user->execute();
        
       
        $conn->commit();
        
        header('Location: ../admin/dashboard.php?msg=user_deleted');
        exit;
    } catch (Exception $e) {
        
        $conn->rollback();
        header('Location: ../admin/dashboard.php?error=delete_failed&message=' . urlencode($e->getMessage()));
        exit;
    }
} else {
    header('Location: ../admin/dashboard.php');
    exit;
}
?>