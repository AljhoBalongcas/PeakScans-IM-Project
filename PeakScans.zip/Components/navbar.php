<?php session_start();
require_once __DIR__ . '/auth.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Resources/style.css">
    <link rel="stylesheet" href="./Resources/user-menu.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
<nav class="navbar custom-navbar px-4 py-2">
  <div class="d-flex align-items-center gap-3 w-100">
    <!-- Logo -->
    <a href="/PEAKSCANS/index.php" class="d-flex align-items-center gap-2 text-decoration-none">
      <img src="./Resources/PeakScansLogo1.jpg" class="circle-icon" alt="Logo">
      <span class="logo-text">PeakScans</span>
    </a>

    <!-- Search Bar -->
    <div class="mx-auto d-flex align-items-center position-relative" style="width: 250px;">
  <span class="position-absolute start-0 ms-2 text-light">
    <i class="bi bi-search"></i>
  </span>
  <input class="form-control small-search ps-5 pe-5" type="search" aria-label="Search">
  <span class="position-absolute end-0 me-2 text-light small" style="pointer-events: none;">Ctrl K</span>
</div>

<div class="d-flex align-items-center nav-links gap-4 me-3">
  <div class="dropdown">
    <a class="text-light text-decoration-none fw-semibold fs-6 dropdown-toggle no-caret" href="#" data-bs-toggle="dropdown">Categories</a>
    <ul class="dropdown-menu dropdown-menu-dark">
    <li><a class="dropdown-item" href="#">Most Popular Webtoon Right Now</a></li>
        <li><a class="dropdown-item" href="#">Most Popular Manga Right Now</a></li>
        <li><a class="dropdown-item" href="#">Browse Comics by Genre</a></li>
        <li><a class="dropdown-item" href="#">Popular Publishers</a></li>
    </ul>
  </div>
  <a class="nav-link text-light fw-semibold fs-6" href="#">Search</a>
  <a class="nav-link text-light fw-semibold fs-6" href="#">My List</a>
</div>

    <!-- Icons -->
    <div class="d-flex align-items-center gap-2">
  <a href="#" class="text-light text-decoration-none">
    <i class="bi bi-person-circle fs-5"></i>
  </a>


  <div class="dropdown">
    <a href="#" class="text-light text-decoration-none dropdown-toggle no-caret" data-bs-toggle="dropdown" aria-expanded="false">
      <i class="bi bi-chevron-down fs-5"></i>
    </a>

    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark">
      <?php if (isset($_SESSION['uid'])): ?>
        <li><span class="dropdown-item-text">Welcome, <?= htmlspecialchars($_SESSION['username']) ?>!</span></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="./Components/logout.php">Logout</a></li>
      <?php else: ?>
        <li><a class="dropdown-item" href="./Components/login.php">Login</a></li>
        <li><a class="dropdown-item" href="./Components/register.php">Register</a></li>
      <?php endif; ?>
    </ul>
  </div>
</div>
  </div>
  <?php if (isset($_SESSION['uid'])): ?>
        <div class="user-menu">
            <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> (<?= $_SESSION['role'] ?>)</span>
            
            <?php if (hasPermission('upload')): ?>
              <a href="./admin/dashboard.php">Dashboard</a>
              <?php endif; ?>

            
            <?php if (hasPermission('upload')): ?>
                <a href="./Pages/upload.php">Upload</a>
            <?php endif; ?>
            
            <a href="./Components/logout.php">Logout</a>
        </div>
    <?php endif; ?>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>

</body>
</html>